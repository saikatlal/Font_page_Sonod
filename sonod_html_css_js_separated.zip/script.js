// পার্টিকেল
(function(){var c=document.getElementById('ptc');for(var i=0;i<30;i++){var p=document.createElement('div');p.className='pt';p.style.left=Math.random()*100+'%';p.style.animationDuration=(Math.random()*15+10)+'s';p.style.animationDelay=Math.random()*15+'s';p.style.width=p.style.height=(Math.random()*2+1)+'px';c.appendChild(p)}})();

// হেডার স্ক্রল
window.addEventListener('scroll',function(){document.getElementById('hd').classList.toggle('scrolled',window.scrollY>50);document.getElementById('btt').classList.toggle('vis',window.scrollY>500)});

// মোবাইল মেনু
document.getElementById('mobT').addEventListener('click',function(){this.classList.toggle('a');document.getElementById('mobM').classList.toggle('open')});
function closeMob(){document.getElementById('mobT').classList.remove('a');document.getElementById('mobM').classList.remove('open')}

// স্লাইড টেক্সট ডাটা — প্রতিটি স্লাইডে আলাদা টেক্সট, অবস্থান স্থির
var SD=[
{badge:'<i class="fas fa-star"></i> বাংলাদেশের প্রথম ডিজিটাল সনদ প্ল্যাটফর্ম',title:'ডিজিটাল বাংলাদেশের <span class="tg">স্মার্ট সনদ সেবা</span>',desc:'বাংলাদেশের প্রথম ডিজিটাল প্ল্যাটফর্মের মাধ্যমে যেকোনো সনদের জন্য অনলাইনে আবেদন করুন। সম্পূর্ণ ডিজিটাল পদ্ধতিতে দ্রুত ও নিরাপদে সেবা পান।',s1:'৯৯.৫%',l1:'সফল আবেদনের হার',s2:'২৪x৭',l2:'সেবা উপলব্ধ',b1:'<i class="fas fa-file-alt"></i> এখনই আবেদন',b1h:'https://v3.sonod.com.bd/auth/citizen-register',b1c:'btn btn-p btn-lg',b2:'<i class="fas fa-play-circle"></i> প্রক্রিয়া দেখুন',b2h:'#auto-process',b2c:'btn btn-gl btn-lg'},
{badge:'<i class="fab fa-google-play"></i> মোবাইল অ্যাপ উপলব্ধ',title:'সনদ অ্যাপ <span class="tg">ডাউনলোড</span> করুন',desc:'অ্যান্ড্রয়েড অ্যাপ থেকে সহজেই সনদ আবেদন করুন। ঘরে বসে মোবাইলেই পান সম্পূর্ণ ডিজিটাল সনদ সেবা। অ্যাপেই পাবেন সকল ফিচার।',s1:'৫০K+',l1:'ডাউনলোড',s2:'৪.৫★',l2:'ইউজার রেটিং',b1:'<i class="fab fa-google-play"></i> অ্যাপ ডাউনলোড',b1h:'https://play.google.com/store/apps/details?id=app.bdfast.sonoddorkar',b1c:'btn btn-p btn-lg',b2:'<i class="fas fa-file-alt"></i> এখনই আবেদন',b2h:'https://v3.sonod.com.bd/auth/citizen-register',b2c:'btn btn-gl btn-lg'},
{badge:'<i class="fas fa-bolt"></i> দ্রুততম সেবা',title:'মুহূর্তেই <span class="tg">সনদ প্রসেসিং</span>',desc:'অত্যাধুনিক প্রযুক্তি ব্যবহার করে সেকেন্ডের মধ্যে আবেদন প্রক্রিয়া সম্পন্ন হয়। দ্রুত ভেরিফিকেশন ও তাৎক্ষণিক সনদ প্রদান ব্যবস্থা।',s1:'৩০ সেকেন্ড',l1:'গড় প্রসেসিং',s2:'৯৫%',l2:'সন্তুষ্টি হার',b1:'<i class="fas fa-file-alt"></i> এখনই আবেদন',b1h:'https://v3.sonod.com.bd/auth/citizen-register',b1c:'btn btn-p btn-lg',b2:'<i class="fas fa-play-circle"></i> প্রক্রিয়া দেখুন',b2h:'#auto-process',b2c:'btn btn-gl btn-lg'},
{badge:'<i class="fas fa-camera"></i> AI প্রযুক্তি',title:'OCR দিয়ে <span class="tg">স্বয়ংক্রিয় নিবন্ধন</span>',desc:'জাতীয় পরিচয়পত্র স্ক্যান করুন, বাকিটা আমরা করব। OCR প্রযুক্তি আপনার এনআইডি থেকে তথ্য স্বয়ংক্রিয়ভাবে পূরণ করে সময় বাঁচায়।',s1:'৯৮%',l1:'নির্ভুলতা',s2:'২ সেকেন্ড',l2:'স্ক্যান সময়',b1:'<i class="fas fa-camera"></i> OCR নিবন্ধন',b1h:'https://v3.sonod.com.bd/auth/citizen-register',b1c:'btn btn-p btn-lg',b2:'<i class="fas fa-file-alt"></i> সাধারণ আবেদন',b2h:'https://v3.sonod.com.bd/auth/citizen-register',b2c:'btn btn-gl btn-lg'},
{badge:'<i class="fas fa-microphone-alt"></i> ভয়েস প্রযুক্তি',title:'কথা বলেই <span class="tg">আবেদন করুন</span>',desc:'ভয়েস রিকগনিশন প্রযুক্তির মাধ্যমে কথা বলে ফর্ম পূরণ করুন। টাইপ করার কোনো প্রয়োজন নেই, বাংলায় কথা বলুন আমরা বুঝব।',s1:'বাংলা',l1:'ভাষা সাপোর্ট',s2:'স্বয়ংক্রিয়',l2:'ফর্ম পূরণ',b1:'<i class="fas fa-microphone-alt"></i> ভয়েস আবেদন',b1h:'https://v3.sonod.com.bd/auth/citizen-register',b1c:'btn btn-p btn-lg',b2:'<i class="fas fa-file-alt"></i> সাধারণ আবেদন',b2h:'https://v3.sonod.com.bd/auth/citizen-register',b2c:'btn btn-gl btn-lg'},
{badge:'<i class="fas fa-receipt"></i> ডিজিটাল পেমেন্ট',title:'হোল্ডিং ট্যাক্স <span class="tg">অনলাইনে পরিশোধ</span>',desc:'বিকাশ, নগদ, রকেট বা কার্ড দিয়ে সহজেই হোল্ডিং ট্যাক্স পরিশোধ করুন। তাৎক্ষণিক ডিজিটাল রসিদ পান এবং রেকর্ড রাখুন।',s1:'৳ ১,৫৫০',l1:'গড় ট্যাক্স',s2:'৪টি',l2:'পেমেন্ট মাধ্যম',b1:'<i class="fas fa-receipt"></i> ট্যাক্স পরিশোধ',b1h:'https://v3.sonod.com.bd/tax-payment',b1c:'btn btn-p btn-lg',b2:'<i class="fas fa-file-alt"></i> সনদ আবেদন',b2h:'https://v3.sonod.com.bd/auth/citizen-register',b2c:'btn btn-gl btn-lg'},
{badge:'<i class="fab fa-chrome"></i> Chrome Extension',title:'ইন্সটল করুন <span class="tg">ক্রোম এক্সটেনশন</span>',desc:'আমাদের ক্রোম এক্সটেনশন ব্যবহার করে স্বয়ংক্রিয়ভাবে তথ্য পূরণ করুন। এক ক্লিকেই সনদের স্ট্যাটাস চেক এবং অন্যান্য সুবিধা উপভোগ করুন।',s1:'দ্রুত',l1:'এক ক্লিকে কাজ',s2:'অটোফিল',l2:'স্বয়ংক্রিয় তথ্য পূরণ',b1:'<i class="fab fa-chrome"></i> ক্রোম ওয়েব স্টোর',b1h:'https://chromewebstore.google.com/detail/%E0%A6%B8%E0%A6%A8%E0%A6%A6-%E0%A6%87%E0%A6%89%E0%A6%A8%E0%A6%BF%E0%A6%AF%E0%A6%BC%E0%A6%A8-%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%B7%E0%A6%A6-%E0%A6%AA%E0%A7%8C%E0%A6%B0%E0%A6%B8%E0%A6%AD%E0%A6%BE/lcodpbcjcnokeamonhlpfagbbchgfjap',b1c:'btn btn-p btn-lg',b2:'<i class="fas fa-shield-alt"></i> নিরাপদ অটোফিল',b2h:'https://chromewebstore.google.com/detail/%E0%A6%B8%E0%A6%A8%E0%A6%A6-%E0%A6%87%E0%A6%89%E0%A6%A8%E0%A6%BF%E0%A6%AF%E0%A6%BC%E0%A6%A8-%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%B7%E0%A6%A6-%E0%A6%AA%E0%A7%8C%E0%A6%B0%E0%A6%B8%E0%A6%AD%E0%A6%BE/lcodpbcjcnokeamonhlpfagbbchgfjap',b2c:'btn btn-gl btn-lg'}
];

var aS=document.querySelectorAll('.h-anim-slide'),dS=document.querySelectorAll('.s-dot'),cS=0,SI=8000,sT;

function goSlide(n){
  aS.forEach(function(s){s.classList.remove('active')});
  dS.forEach(function(d){d.classList.remove('active')});
  cS=((n%aS.length)+aS.length)%aS.length;
  aS[cS].classList.add('active');
  dS[cS].classList.add('active');
  // শুধু টেক্সট কন্টেন্ট পরিবর্তন, অবস্থান একদম নড়বে না
  var d=SD[cS];
  document.getElementById('hBadge').innerHTML=d.badge;
  document.getElementById('hTitle').innerHTML=d.title;
  document.getElementById('hDesc').textContent=d.desc;
  document.getElementById('hS1').textContent=d.s1;
  document.getElementById('hL1').textContent=d.l1;
  document.getElementById('hS2').textContent=d.s2;
  document.getElementById('hL2').textContent=d.l2;
  var b1=document.getElementById('hBtn1');b1.innerHTML=d.b1;b1.href=d.b1h;b1.className=d.b1c;
  var b2=document.getElementById('hBtn2');b2.innerHTML=d.b2;b2.href=d.b2h;b2.className=d.b2c;
}
function resetT(){clearInterval(sT);sT=setInterval(function(){goSlide(cS+1)},SI)}
document.getElementById('sNext').addEventListener('click',function(){goSlide(cS+1);resetT()});
document.getElementById('sPrev').addEventListener('click',function(){goSlide(cS-1);resetT()});
dS.forEach(function(d){d.addEventListener('click',function(){goSlide(+this.dataset.s);resetT()})});
sT=setInterval(function(){goSlide(cS+1)},SI);

// রিভিল অন স্ক্রল
var rE=document.querySelectorAll('.rv');
var rO=new IntersectionObserver(function(e){e.forEach(function(en){if(en.isIntersecting){en.target.classList.add('vis');rO.unobserve(en.target)}})},{threshold:.15,rootMargin:'0px 0px -8% 0px'});
rE.forEach(function(el){rO.observe(el)});

// কাউন্টার
var sN=document.querySelectorAll('.st-num[data-count]');
var cO=new IntersectionObserver(function(e){e.forEach(function(en){if(en.isIntersecting){var t=+en.target.dataset.count;var c=0;var s=Math.ceil(t/60);var tm=setInterval(function(){c+=s;if(c>=t){c=t;clearInterval(tm)}en.target.textContent=c.toLocaleString('bn-BD')+'+'},30);cO.unobserve(en.target)}})},{threshold:.5});
sN.forEach(function(el){cO.observe(el)});

// ব্যাক টু টপ
document.getElementById('btt').addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'})});

// ভয়েস ফর্ম অ্যানিমেশন
var vR=document.querySelectorAll('.v-row'),vI=0;
setInterval(function(){vR.forEach(function(r){r.classList.remove('filled')});vI=(vI+1)%vR.length;for(var i=0;i<=vI;i++)vR[i].classList.add('filled')},3500);

// সার্ভিস মোডাল
var SM={family:{icon:'fas fa-users',bg:'linear-gradient(135deg,#1a56db,#1e40af)',title:'পারিবারিক সনদ',desc:'অনলাইনে পারিবারিক সনদের জন্য আবেদন করুন। সম্পূর্ণ ডিজিটাল প্রক্রিয়ায় কয়েক মিনিটেই আবেদন সম্পন্ন করুন। অনুমোদনের পর ডাউনলোড করুন আপনার সনদ।',tags:['ডিজিটাল আবেদন','QR কোড যাচাই','এসএমএস নোটিফিকেশন','তাৎক্ষণিক ডাউনলোড']},succession:{icon:'fas fa-file-contract',bg:'linear-gradient(135deg,#7c3aed,#5b21b6)',title:'উত্তরাধিকার সনদ',desc:'মৃত ব্যক্তির উত্তরাধিকার সম্পত্তি নির্ধারণের জন্য উত্তরাধিকার সনদ আবেদন করুন ডিজিটাল পদ্ধতিতে।',tags:['আইনি স্বীকৃতি','ওয়ারিশ তালিকা','ডিজিটাল ভেরিফিকেশন','নিরাপদ প্রক্রিয়া']},death:{icon:'fas fa-heart-broken',bg:'linear-gradient(135deg,#dc2626,#991b1b)',title:'মৃত্যু সনদ',desc:'মৃত্যু সনদ অনলাইনে আবেদন ও প্রাপ্তির সুবিধা। ডিজিটাল পদ্ধতিতে দ্রুত ও নিরাপদে মৃত্যু সনদ পান।',tags:['দ্রুত প্রক্রিয়া','ডিজিটাল রেকর্ড','ভেরিফাইড সনদ','পিডিএফ ডাউনলোড']},nationality:{icon:'fas fa-flag',bg:'linear-gradient(135deg,#059669,#047857)',title:'জাতীয়তা সনদ',desc:'বাংলাদেশের নাগরিকত্ব প্রমাণের জন্য জাতীয়তা সনদ অনলাইনে আবেদন করুন।',tags:['নাগরিকত্ব প্রমাণ','সরকারি স্বীকৃতি','ডিজিটাল ফরম্যাট','যাচাই সুবিধা']},tax:{icon:'fas fa-receipt',bg:'linear-gradient(135deg,#f59e0b,#d97706)',title:'হোল্ডিং ট্যাক্স',desc:'অনলাইনে হোল্ডিং ট্যাক্স পরিশোধ করুন বিকাশ, নগদ, কার্ড বা অন্য কোনো ডিজিটাল পেমেন্টের মাধ্যমে।',tags:['বিকাশ পেমেন্ট','নগদ পেমেন্ট','কার্ড পেমেন্ট','ডিজিটাল রসিদ']},vgf:{icon:'fas fa-hand-holding-heart',bg:'linear-gradient(135deg,#f59e0b,#b45309)',title:'ভিজিএফ ও স্পেশাল সার্ভিস',desc:'প্রতি ঈদে ভিজিএফ (Vulnerable Group Feeding) কর্মসূচির আওতায় প্রতিটি উপকারভোগী পরিবারকে ১০ কেজি করে চাউল বিতরণ করা হয়। এই সেবা এখন সম্পূর্ণ ডিজিটাল পদ্ধতিতে পরিচালিত হয়।',tags:['ঈদ বিশেষ','১০ কেজি চাউল','ডিজিটাল তালিকা','পরিবার ভিত্তিক']},ocr:{icon:'fas fa-camera',bg:'linear-gradient(135deg,#06b6d4,#0891b2)',title:'OCR নিবন্ধন',desc:'জাতীয় পরিচয়পত্র (NID) স্ক্যান করে স্বয়ংক্রিয়ভাবে তথ্য পূরণ করুন। OCR প্রযুক্তি আপনার সময় বাঁচায়।',tags:['NID স্ক্যান','স্বয়ংক্রিয় পূরণ','সময় সাশ্রয়','উচ্চ নির্ভুলতা']},voice:{icon:'fas fa-microphone-alt',bg:'linear-gradient(135deg,#ec4899,#be185d)',title:'ভয়েস নিবন্ধন',desc:'কথা বলে আবেদন ফর্ম পূরণ করুন। ভয়েস রিকগনিশন প্রযুক্তি আপনার কণ্ঠস্বর থেকে তথ্য সংগ্রহ করে।',tags:['কণ্ঠস্বর নির্ভর','বাংলা ভাষা','স্বয়ংক্রিয় পূরণ','প্রযুক্তি ভিত্তিক']}};

function openSM(k){var d=SM[k];if(!d)return;document.getElementById('smIcon').style.background=d.bg;document.getElementById('smIcon').innerHTML='<i class="'+d.icon+'"></i>';document.getElementById('smTitle').textContent=d.title;document.getElementById('smDesc').textContent=d.desc;document.getElementById('smTags').innerHTML=d.tags.map(function(t){return'<span class="sTag"><i class="fas fa-check"></i> '+t+'</span>'}).join('');document.getElementById('vgfBox').style.display=k==='vgf'?'block':'none';document.getElementById('smOv').classList.add('open')}
document.getElementById('smOv').addEventListener('click',function(e){if(e.target===this)this.classList.remove('open')});

// যোগাযোগ পেজ
function openContactPage(){document.getElementById('contactPage').classList.add('open');document.body.style.overflow='hidden'}
function closeContactPage(){document.getElementById('contactPage').classList.remove('open');document.body.style.overflow=''}
function openFAQPage(){document.getElementById('faqPage').classList.add('open');document.body.style.overflow='hidden'}
function closeFAQPage(){document.getElementById('faqPage').classList.remove('open');document.body.style.overflow=''}

// লিগাল মোডাল
function openLegal(t){document.getElementById('legal'+t.charAt(0).toUpperCase()+t.slice(1)).classList.add('open');document.body.style.overflow='hidden'}
function closeLegal(t){document.getElementById('legal'+t.charAt(0).toUpperCase()+t.slice(1)).classList.remove('open');document.body.style.overflow=''}
document.querySelectorAll('.legal-ov').forEach(function(m){m.addEventListener('click',function(e){if(e.target===this){this.classList.remove('open');document.body.style.overflow=''}})});
document.querySelectorAll('.faq-q').forEach(function(btn){btn.addEventListener('click',function(){var item=this.closest('.faq-item');document.querySelectorAll('.faq-item.open').forEach(function(openItem){if(openItem!==item)openItem.classList.remove('open')});item.classList.toggle('open')})});
function showPartner(title,desc){document.getElementById('smIcon').style.background='linear-gradient(135deg,#1a56db,#1e40af)';document.getElementById('smIcon').innerHTML='<i class="fas fa-handshake"></i>';document.getElementById('smTitle').innerHTML=title;document.getElementById('smDesc').innerHTML=desc;document.getElementById('smTags').innerHTML='<span class="sTag"><i class="fas fa-globe"></i> ওয়েবসাইট</span><span class="sTag"><i class="fas fa-circle-info"></i> অংশীদার সংস্থা</span><span class="sTag"><i class="fas fa-shield-alt"></i> নিরাপদ সেবা</span>';document.getElementById('smLink').href='#partners';document.getElementById('vgfBox').style.display='none';document.getElementById('smOv').classList.add('open');document.body.style.overflow='hidden'}


// অটো জুম প্রসেস
(function(){var st=document.querySelectorAll('.zoom-step'),cn=document.querySelectorAll('.zoom-connector'),a=0,ZI=2500;function zc(){st.forEach(function(s){s.classList.remove('zoom-active')});cn.forEach(function(c){c.classList.remove('filled')});st[a].classList.add('zoom-active');for(var i=0;i<a;i++)cn[i].classList.add('filled');a=(a+1)%st.length}setInterval(zc,ZI)})();

// মার্কি হাইড
var lS=0;window.addEventListener('scroll',function(){var s=window.scrollY;if(s>lS&&s>200)document.getElementById('mqBar').classList.add('hide');else document.getElementById('mqBar').classList.remove('hide');lS=s});

// স্মুথ স্ক্রল
document.querySelectorAll('a[href^="#"]').forEach(function(a){a.addEventListener('click',function(e){var t=document.querySelector(this.getAttribute('href'));if(t){e.preventDefault();t.scrollIntoView({behavior:'smooth'})}})});

// ESC
document.addEventListener('keydown',function(e){if(e.key==='Escape'){document.getElementById('smOv').classList.remove('open');closeContactPage();closeFAQPage();document.querySelectorAll('.legal-ov.open').forEach(function(m){m.classList.remove('open')});document.body.style.overflow=''}});
